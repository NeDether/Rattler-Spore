#!/bin/bash

java -jar 'SporeModderFX.jar' $@
